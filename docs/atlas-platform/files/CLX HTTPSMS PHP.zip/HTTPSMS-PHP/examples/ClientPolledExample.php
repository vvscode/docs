<?php

# Copyright 2007 CardBoardFish
# http://www.cardboardfish.com/
# See readme.txt for terms of use. 

# This code works on the live system - current delivery receipts are
# required for the code to produce output. 
#
# See SendSMSExample.php for an example of how to send a message with a
# delivery receipt request.

require_once("ClientPolled.php");
require_once("IncomingFormat.php");

# Your username and password go here
# These MUST be set before calling poll()
$sms_username = "username";
$sms_password = "password";

$responses = poll() or die ("Error: " . $errstr . "\n");
determineType($responses);

?>
