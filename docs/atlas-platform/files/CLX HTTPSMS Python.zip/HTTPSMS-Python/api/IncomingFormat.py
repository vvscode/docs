"""This python module is designed to facilitate the construction of
   applications which communicate with HTTPSMS servers. This particular
   file processes delivery receipt and incoming SMS information.

   This module should be imported in the usual way.

   Copyright (C) 2007 CardBoardFish http://www.cardboardfish.com/"""

__all__ = ("processIncoming", "determineType", "incomingSMS", "deliveryReceipt")

def processIncoming(receiptstring):
    """Process delivery receipt information. This function accepts
       the server's response format of records separated by hash
       characters (#) and returns a list of lists. Each sublist
       contains strings representing the returned fields."""
    to_return, receipts = [], receiptstring.split("#")
    receipts.pop(0)

    for receipt in receipts:
        if receipt == '':
            continue
        field = receipt.split(":")
        to_return.append(field)
    return to_return

def determineType(responses):
    """Examines each element of the response string given by
       processIncoming, determines whether each response is a
       delivery receipt or an incoming SMS, and calls the appropriate
       print routine to display the information. Takes as input the
       list returned by processIncoming."""
    for message in responses:
        type = message[0]
        if type == "-1":
            incomingSMS(message)
        else:
            deliveryReceipt(message)
        print

def deliveryReceipt(fields):
    """Given the fields of a delivery receipt, prints out field
       labels and data in a simple, line-based format. Each line
       printed will have a key name, a colon, a space and a
       field, e.g.

       MSGID: 1128173 
       SOURCE: 447111111111
       DESTINATION: 447000000000
       STATUS: 1
       ERRORCODE: 0
       DATETIME: 1180019698
       USERREF: AF31C0D"""
    print "MSGID: " + fields[0]
    print "SOURCE: " + fields[1]
    print "DESTINATION: " + fields[2]
    print "STATUS: " + fields[3]
    print "ERRORCODE: " + fields[4]
    print "DATETIME: " + fields[5]
    print "USERREF: " + fields[6]

def incomingSMS(fields):
    """Given the fields of an incoming SMS, prints out field labels and
       data in a simple, line-based format. Each line printed will have
       a key name, a colon, a space and a field, e.g.

       SOURCE: 447111111112
       DESTINATION: 447000000003
       DCS: 1
       DATETIME: 1180019700
       UDH:
       MESSAGE: 48656C6C6F"""
    print "SOURCE: " + fields[1]
    print "DESTINATION: " + fields[2]
    print "DCS: " + fields[3]
    print "DATETIME: " + fields[5]
    print "UDH: " + fields[6]
    print "MESSAGE: " + (_hexDecode(fields[7]))

def _hexDecode(input):
    to_return = ""
    for i in range(0,len(input), 2):
        mychr = int(input[i:i+2], 16);
        to_return += (chr(mychr))
    return to_return
