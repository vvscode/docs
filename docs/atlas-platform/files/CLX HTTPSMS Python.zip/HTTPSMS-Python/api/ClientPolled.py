"""This python module is designed to facilitate the construction of
   applications which communicate with HTTPSMS servers. This file
   contains a poll method to retrieve delivery receipt and
   incoming SMS information from the server.

   This module should be imported in the usual way. Any misuse of its
   functions is likely to result in an SMSClientError, which should
   indicate the problem.

   Copyright (C) 2007 CardBoardFish http://www.cardboardfish.com/"""
import httplib

from urllib import quote_plus as _quote
from time import time as _time
import sys
import re

from SendSMS import SMSClientError
import IncomingFormat

__all__ = ("poll")

def init(un, p):
    """Initialises the library.

       Given a username and password, this function sets up this
       module to interact with HTTPSMS servers."""
    global username, password
    username, password = un, p

def poll():
    """Once the module has been initialised, simply call this method
       like so:

           responses = ClientPolled.poll()

       If used in an incorrect way, an SMSClientError will be thrown.
       It is recommended you catch these and print the exception."""
    try:
        requeststring = '/ClientDR/ClientDR?UN=' \
          + username + '&P=' + password
    except NameError:
        raise SMSClientError('Module not initialised.')
    try:
        server = httplib.HTTPConnection('sms1.cardboardfish.com:9001')
    except IOError, e: raise SMSClientError(str(e))
    server.request('GET', requeststring)
    response = server.getresponse()
    code = response.status
    if code == 400: raise SMSClientError('Received "Bad Request" \
      response code from server.')
    elif code == 401: raise SMSClientError('Bad username / \
      password.')
    elif code == 500:
        raise SMSClientError('Internal server error.')
    elif code != 200: raise SMSClientError('Unhandled error: ' \
      + str(response.status) + ' ' + response.reason + ' ' \
      + response.read())
    responsestring = response.read()
    replies = IncomingFormat.processIncoming(responsestring)
    return replies
