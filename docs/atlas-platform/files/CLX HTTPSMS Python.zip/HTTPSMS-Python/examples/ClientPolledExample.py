#!/usr/bin/env python

# Copyright 2007 CardBoardFish
# http://www.cardboardfish.com/
# See readme.txt for terms of use. 

# This code works on the live system - current delivery receipts are
# required for the code to produce output. 
#
# See SendSMSExample.py for an example of how to send a message with a
# delivery receipt request.

from SendSMS import SMSClientError
import ClientPolled
import IncomingFormat

# Your username and password go here
username = "username"
password = "password"

ClientPolled.init(username, password)

try:
    messages = ClientPolled.poll()
    IncomingFormat.determineType(messages)
except SMSClientError, e:
    print e
