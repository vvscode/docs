#!/usr/bin/env python
# Copyright 2007 CardBoardFish
# http://www.cardboardfish.com/
# See readme.txt for terms of use.

import IncomingFormat
 
# Test data - normally the data will come from the server.
data = "2#1128173:447111111111:447000000000:1:0:1180019698:AF31C0D:#-1:447111111112:447000000003:1:1180019700::48656C6C6F"

# Process the data
messages = IncomingFormat.processIncoming(data)

# Print the data to standard output
IncomingFormat.determineType(messages)
