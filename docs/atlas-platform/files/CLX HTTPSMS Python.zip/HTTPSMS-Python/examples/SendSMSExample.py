#!/usr/bin/env python

# Copyright 2007 CardBoardFish
# http://www.cardboardfish.com/
# See readme.txt for terms of use. 

from SendSMS import *
import SendSMS

# Your username and password go here
username = "username"
password = "password"

# Change the destination to your desired test destination
destination = "447000000000"
source =      "447111111111"

def example7_1():
    """Plain Text SMS

       Plain SMS with User Reference and delivery receipt request"""

    # Construct an SMS object
    sms = SMS({ 'da': destination, 'sa': source, 'm': "Hello" })

    # Set the user reference, and set delivery receipts to 1
    sms.setOptional( { 'ur': 'AF31C0D', 'dr': '1' } )

    responses = sendSMS({ 'SMS': sms });
    print "Example 7.1 Response:"
    for response in responses:
        print "\t" + response

def example7_2():
    """Flash SMS

       Plain flash SMS with User Reference and delivery receipt
       request"""

    # Call sendSMS with a dictionary of parameters
    responses = sendSMS({ 'da': destination, 'sa': source, 'm': "Hello", 'optional': {'dc': "0", 'dr': "1", 'ur': "MSG_1"} });

    print "Example 7.2 Response:"
    for response in responses:
        print "\t" + response

def example7_3():
    """Nokia Ringtone

       Ringtone with originator address set to FreeTone"""

    # Construct an SMS object with some initial parameters
    # Note that for an alphanumeric source address, source type
    # must be set to "5".
    sms = SMS({ 'da': destination, 'sa': 'FreeTone', 'optional': {'st': "5"} })

    # Set the user reference, and set delivery receipts to 1
    sms.setOptional( { 'dc': '2', 'ud': "06050415810000" } )
    sms.setMSG("024A3A7D0995D995C9B195E521A5B1B1CD0DBC0400FD1CD496610624CB084125A242892D049B890A24B31251892CC20C511610824B4485125A0A251214511624CB125A2428A231214516890A24B4125224289290491890A24C31258840841892CC20C499610824B4485125A09371214496624A312598418A22C210496890A24B4144A2428A")

    responses = sendSMS({ 'SMS': sms });
    print "Example 7.3 Response:"
    for response in responses:
        print "\t" + response

def example7_4():
    """Nokia Operator Logo

       Operator Logo with numeric originator address, User Reference
       and delivery receipt recorded on account only."""

    sms = SMS({ 'da': destination, 'sa': source })

    sms.setOptional( { 'ur': "LO_5", 'st': "1" } )
    sms.setOptional( { 'dc': '2', 'ud': "06050415820000" } )
    sms.setMSG("32F43300480E010000000000000000000000000000000000000000000000000000000000000000000000003E0005F800004FA06060000D980000D8006060F7BD99CF7BD86F7C6036ADF3636ADFEC6C60F6AD9B6F6AD86F6C60B62D9B6B62D8616C3EF63DF1CF63D86F6C000000000000000000000000000000000000000000000000000000")

    responses = sendSMS({ 'SMS': sms });
    print "Example 7.4 Response:"
    for response in responses:
        print "\t" + response

def example7_5():
    """WAP Push

       WAP Push with originator set to Download"""

    sms = SMS({'da': destination, 'sa': "Download", \
        'optional': { 'st': "5" }})

    sms.setOptional( { 'dc': '2', 'ud': "0605040B8423F0" } )
    sms.setMSG("01060403AE81EA0205040045C60B037777772E63617264626F617264666973682E636F6D00010343617264426F61726446697368202D20546865204E6578742047656E65726174696F6E206F66204D6F62696C65204D6573736167696E67000101")

    responses = sendSMS({ 'SMS': sms });
    print "Example 7.5 Response:"
    for response in responses:
        print "\t" + response

def example7_6():
    """VCard

       VCard with originator set to Mike"""

    sms = SMS({'da': destination, 'sa': "Mike"})
    # ST will be set implicitly

    sms.setOptional( { 'dc': '2', 'ud': "06050423F423F4" } )
    sms.setMSG("424547494E3A56434152440D0A56455253494F4E3A322E310D0A4E3A536D6974683B4D696B650D0A54454C3B505245463A2B34343731323334350D0A454E443A56434152440D0A")

    responses = sendSMS({ 'SMS': sms });
    print "Example 7.6 Response:"
    for response in responses:
        print "\t" + response

def example7_7():
    """Unicode

       Unicode message"""

    sms = SMS({'da': destination, 'sa': source })

    sms.setOptional( { 'dc': '4' } )
    sms.setMSG("00430061007200640042006f00610072006400460069007300680020002d00200054006800650020004e006500780074002000470065006e00650072006100740069006f006e0020006f00660020004d006f00620069006c00650020004d006500730073006100670069006e0067")

    responses = sendSMS({ 'SMS': sms });
    print "Example 7.7 Response:"
    for response in responses:
        print "\t" + response

def example7_8():
    """Concatenated SMS

       Long plain message with User Reference and delivery receipt.
       This message is 163 characters long so it would require 2 SMS."""

    sms = SMS({'da': destination, 'sa': source })
    sms.setOptional( { 'ur': 'MSG_1' } )
    sms.setMSG("Hi! The train is delayed so please pick me up from London road train station. Let me know if you can make it because if not I will catch a taxi. Speak to you soon.");

    responses = sendSMS({ 'SMS': sms });
    print "Example 7.8 Response:"
    for response in responses:
        print "\t" + response

try:
    SendSMS.init(username,password)
    # example7_1()
    # example7_2()
    # example7_3()
    # example7_4()
    # example7_5()
    # example7_6()
    # example7_7()
    # example7_8()
except SMSClientError, e:
    print e
