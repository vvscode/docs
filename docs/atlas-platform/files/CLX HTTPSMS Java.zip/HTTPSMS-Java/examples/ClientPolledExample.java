/**
 *  ClientPolledExample.java
 *
 *  Copyright 2007 CardBoardFish
 *  http://www.cardboardfish.com/
 *  See readme.txt for terms of use.
 *
 *  This code works on the live system - current delivery receipts are
 *  required for the code to produce output.
 *
 *  See SendSMSExample.java for an example of how to send a message
 *  with a delivery receipt request.
 *
 */
public class ClientPolledExample {

    private static final String username = "username";
    private static final String password = "password";

    public static void main(String[] args) {
        try {
            ClientPolledExample e = new ClientPolledExample(username, password);
            e.example();
        } catch (SMSClientException e) {
            System.err.println(e.getMessage());
        }
    }

    public ClientPolledExample(String username, String password) throws SMSClientException {
        ClientPolled.initialise(username, password);
    }

    public void example() throws SMSClientException {
        String[][] response = ClientPolled.poll();
        IncomingFormat.determineType(response);
    }

}
