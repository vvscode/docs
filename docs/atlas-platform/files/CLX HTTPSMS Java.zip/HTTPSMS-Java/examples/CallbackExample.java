/**
 *  CallbackExample.java
 *
 *  Copyright 2007 CardBoardFish
 *  http://www.cardboardfish.com/
 *  See readme.txt for terms of use.
 *
 */
public class CallbackExample {

    /* Test data - normally the data will come from the server. */
    private static String incoming = "2#1128173:447111111111:447000000000:1:0:1180019698:AF31C0D:#-1:447111111112:447000000003:1:1180019700::48656C6C6F";

    public static void main (String[] args) {
        /* Process the data */
        String[][] response = IncomingFormat.processIncoming(incoming);

        /* Print the data to standard output */
        IncomingFormat.determineType(response);
    }
}
