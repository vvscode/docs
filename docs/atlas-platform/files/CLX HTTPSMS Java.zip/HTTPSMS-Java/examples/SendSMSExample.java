/**
 *  SendSMSExample.java
 *
 *  Copyright 2007 CardBoardFish
 *  http://www.cardboardfish.com/
 *  See readme.txt for terms of use.
 *
 *  Before running the examples, please inspect the commented
 *  attributes at the top of the source, and edit them appropriately.
 *  Each example has its own method; uncomment the calls in main
 *  for the examples you wish to run.
 *
 */
public class SendSMSExample {

    /* Your username and password go here */
    private static final String username = "username";
    private static final String password = "password";

    /* Replace the destination number with your test destination */
    private static final String[] destination = { "447000000000" };
    private static final String source =          "447111111111";

    public static void main(String[] args) {
        try {
            SendSMSExample e = new SendSMSExample(username, password);
        //    e.example7_1();
        //    e.example7_2();
        //    e.example7_3();
        //    e.example7_4();
        //    e.example7_5();
        //    e.example7_6();
        //    e.example7_7();
        //    e.example7_8();
        } catch (SMSClientException e) {
            System.err.println(e.getMessage());
        }
    }

    private SendSMSExample(String username, String password) throws SMSClientException {
        SendSMS.initialise(username, password);
    }

    /**
     *  Plain Text SMS
     *
     *  Plain SMS with User Reference and delivery receipt request
     *
     */
    private void example7_1() throws SMSClientException {
        /* Construct an SMS object */
        SMS sms = new SMS();

        /* Set the destination address */
        sms.setDestination(destination);

        /* Set the source address */
        sms.setSourceAddr(source);

        /* Set the user reference */
        sms.setUserReference("AF31C0D");

        /* Set delivery receipts to 'on' */
        sms.setDR("1");

        /* Set the message content */
        sms.setMessage("Hello");

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.1 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

    /**
     *  Flash SMS
     *
     *  Plain flash SMS with User Reference and delivery receipt request
     *
     */
    private void example7_2() throws SMSClientException {
        /* Construct an SMS object with initial fields filled in */
        SMS sms = new SMS(destination, source, null, "Hello", "0", "1", null, "MSG_1", null, null, null);

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.2 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

    /**
     *  Nokia Ringtone
     *
     *  Ringtone with originator address set to FreeTone
     *
     */
    private void example7_3() throws SMSClientException {
        SMS sms = new SMS();

        sms.setDestination(destination);

        /* Set the source address to an alphanumeric, and */
        sms.setSourceAddr("FreeTone");
        /* the source type is set to alphanumeric implicitly */

        /* Set the encoding, user data header and message */
        sms.setDC("2");
        sms.setUD("06050415810000");
        sms.setMessage("024A3A7D0995D995C9B195E521A5B1B1CD0DBC0400FD1CD496610624CB084125A242892D049B890A24B31251892CC20C511610824B4485125A0A251214511624CB125A2428A231214516890A24B4125224289290491890A24C31258840841892CC20C499610824B4485125A09371214496624A312598418A22C210496890A24B4144A2428A");

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.3 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

    /**
     *  Nokia Operator Logo
     *
     *  Operator Logo with numeric originator addres, User Reference and
     *  delivery receipt recorded on account only.
     *
     */
    private void example7_4() throws SMSClientException {
        SMS sms = new SMS();

        sms.setDestination(destination);
        sms.setSourceAddr(source);
        sms.setDR("2");
        sms.setUserReference("LO_5");
        sms.setDC("2");
        sms.setUD("06050415820000");
        sms.setMessage("32F43300480E010000000000000000000000000000000000000000000000000000000000000000000000003E0005F800004FA06060000D980000D8006060F7BD99CF7BD86F7C6036ADF3636ADFEC6C60F6AD9B6F6AD86F6C60B62D9B6B62D8616C3EF63DF1CF63D86F6C000000000000000000000000000000000000000000000000000000");

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.4 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

    /**
     *  WAP Push
     *
     *  WAP Push with originator set to Download
     *
     */
    private void example7_5() throws SMSClientException {
        SMS sms = new SMS();

        sms.setDestination(destination);
        sms.setSourceAddr("Download");
        sms.setDC("2");
        sms.setUD("0605040B8423F0");
        sms.setMessage("01060403AE81EA0205040045C60B037777772E63617264626F617264666973682E636F6D00010343617264426F61726446697368202D20546865204E6578742047656E65726174696F6E206F66204D6F62696C65204D6573736167696E67000101");

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.5 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

    /**
     *  VCard
     *
     *  VCard with originator set to Mike.
     *
     */
    private void example7_6() throws SMSClientException {
        SMS sms = new SMS();

        sms.setDestination(destination);
        sms.setSourceAddr("Mike");
        sms.setDC("2");
        sms.setUD("06050423F423F4");
        sms.setMessage("424547494E3A56434152440D0A56455253494F4E3A322E310D0A4E3A536D6974683B4D696B650D0A54454C3B505245463A2B34343731323334350D0A454E443A56434152440D0A");

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.6 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

    /**
     *  Unicode
     *
     *  Unicode message.
     *
     */
    private void example7_7() throws SMSClientException {
        SMS sms = new SMS();

        sms.setDestination(destination);
        sms.setSourceAddr(source);
        sms.setDC("4");
        sms.setMessage("00430061007200640042006f00610072006400460069007300680020002d00200054006800650020004e006500780074002000470065006e00650072006100740069006f006e0020006f00660020004d006f00620069006c00650020004d006500730073006100670069006e0067");

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.7 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

    /**
     *  Concatenated SMS
     *
     *  Long plain message with User Reference and delivery receipt.
     *  This message is 163 characters long so it would require 2 SMS.
     *
     */
    private void example7_8() throws SMSClientException {
        SMS sms = new SMS();

        sms.setDestination(destination);
        sms.setSourceAddr(source);
        sms.setUserReference("MSG_1");
        sms.setMessage("Hi! The train is delayed so please pick me up from London road train station. Let me know if you can make it because if not I will catch a taxi. Speak to you soon.");

        int[] responses = SendSMS.sendSMS(sms);
        System.out.println("Example 7.8 Response:");
        for (int i = 0; i < responses.length; i++) {
            System.out.println("\t" + responses[i]);
        }
    }

}
