CARDBOARDFISH HTTPSMS JAVA API V1.4.1 01/07/10
Copyright 2007-2010 CardBoardFish www.cardboardfish.com

This package contains the following directories:

api - The Java HTTPSMS API Library
doc - HTML documentation
examples - Source code demonstrating how to interact with the API

For further information and support please visit www.cardboardfish.com.

INSTALLATION

Compile your program with cbfsms.jar in the classpath, e.g.

    javac -classpath "cbfsms.jar:." CallbackExample.java

then run your program with cbfsms.jar also in your classpath, e.g.

    java -classpath "cbfsms.jar:." CallbackExample

Your program should probably include this line:

    import CBFSMS.*;

Consult the Java documentation for further information.

NOTE

Examples must be run in the same folder as the API class files. Edit the
variables at the top to reflect your settings, e.g. your account's
username and password, a number to send test messages to.

THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
CARDBOARDFISH BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, IN ANY
CIRCUMSTANCES, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR ITS
USE.
