'SendSMSExample.java

'Copyright 2007 CardBoardFish
'http://www.cardboardfish.com/
'See readme.txt for terms of use.

'Before running the examples, please inspect the commented
'attributes at the top of the source, and edit them appropriately.
'Each example has its own method; uncomment the calls in main
'for the examples you wish to run.

'Reference the HTTPSMS DLL:
Imports HTTPSMS

Module SendSMSExample

    'Your username and password go here */
    Private username As String = "username"
    Private password As String = "password"

    'Replace the destination number with your test destination
    Private destination() As String = {"447000000000"}
    Private source As String = "447111111111"

    Private sendSMS As New HTTPSMS.SendSMS

    Public Sub Main()
        Try
            SendSMSExample(username, password)
            '   example7_1()
            '   example7_2()
            '   example7_3()
            '   example7_4()
            '   example7_5()
            '   example7_6()
            '   example7_7()
            '   example7_8()
        Catch SMSClientEx As HTTPSMS.SMSClientException
            Console.WriteLine(SMSClientEx.Message)
        End Try
    End Sub

    Private Sub SendSMSExample(ByVal username As String, ByVal password As String)
        sendSMS.initialise(username, password)
    End Sub

    'Plain Text SMS

    'Plain SMS with User Reference and delivery receipt request

    Private Sub example7_1()
        'Construct an SMS object
        Dim SMS As New HTTPSMS.SMS

        'Set the destination address
        SMS.setDestination(destination)

        'Set the source address
        SMS.setSourceAddr(source)

        'Set the user reference
        SMS.setUserReference("AF31C0D")

        'Set delivery receipts to 'on'
        SMS.setDR("1")

        'Set the message content
        SMS.setMessage("Hello")

        Try
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.1 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch ex7_1Ex As HTTPSMS.SMSClientException
            Console.WriteLine(ex7_1Ex.Message)
            Return
        End Try
    End Sub

    'Flash SMS

    'Plain flash SMS with User Reference and delivery receipt request

    Private Sub example7_2()
        'Construct an SMS object with initial fields filled in
        Try
            Dim SMS As New HTTPSMS.SMS(destination, source, Nothing, "Hello", "0", "1", Nothing, "MSG_1", Nothing, Nothing, Nothing)
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.2 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch ex7_2Ex As HTTPSMS.SMSClientException
            Console.WriteLine(ex7_2Ex.Message)
            Return
        End Try
    End Sub

    'Nokia Ringtone

    'Ringtone with originator address set to FreeTone

    Private Sub example7_3()
        Try
            Dim SMS As New SMS
            SMS.setDestination(destination)
            'Set the source address to an alphanumeric, and
            SMS.setSourceAddr("FreeTone")
            'the source type is set to alphanumeric implicitly
            'Set the encoding, user data header and message
            SMS.setDC("2")
            SMS.setUD("06050415810000")
            SMS.setMessage("024A3A7D0995D995C9B195E521A5B1B1CD0DBC0400FD1CD496610624CB084125A242892D049B890A24B31251892CC20C511610824B4485125A0A251214511624CB125A2428A231214516890A24B4125224289290491890A24C31258840841892CC20C499610824B4485125A09371214496624A312598418A22C210496890A24B4144A2428A")
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.3 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch Ex7_3Ex As HTTPSMS.SMSClientException
            Console.WriteLine(Ex7_3Ex.Message)
            Return
        End Try
    End Sub

    'Nokia Operator Logo

    'Operator Logo with numeric originator addres, User Reference and
    'delivery receipt recorded on account only.

    Private Sub example7_4()
        Try
            Dim SMS As New SMS
            SMS.setDestination(destination)
            SMS.setSourceAddr(source)
            SMS.setDR("2")
            SMS.setUserReference("LO_5")
            SMS.setDC("2")
            SMS.setUD("06050415820000")
            SMS.setMessage("32F43300480E010000000000000000000000000000000000000000000000000000000000000000000000003E0005F800004FA06060000D980000D8006060F7BD99CF7BD86F7C6036ADF3636ADFEC6C60F6AD9B6F6AD86F6C60B62D9B6B62D8616C3EF63DF1CF63D86F6C000000000000000000000000000000000000000000000000000000")
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.4 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch Ex7_4Ex As HTTPSMS.SMSClientException
            Console.WriteLine(Ex7_4Ex.Message)
            Return
        End Try
    End Sub

    'WAP Push

    'WAP Push with originator set to Download

    Private Sub example7_5()
        Try
            Dim SMS As New SMS
            SMS.setDestination(destination)
            SMS.setSourceAddr("Download")
            SMS.setDC("2")
            SMS.setUD("0605040B8423F0")
            SMS.setMessage("01060403AE81EA0205040045C60B037777772E63617264626F617264666973682E636F6D00010343617264426F61726446697368202D20546865204E6578742047656E65726174696F6E206F66204D6F62696C65204D6573736167696E67000101")
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.5 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch ex7_5Ex As HTTPSMS.SMSClientException
            Console.WriteLine(ex7_5Ex.Message)
            Return
        End Try
    End Sub

    'VCard

    'VCard with originator set to Mike.

    Private Sub example7_6()
        Try
            Dim SMS As New SMS
            SMS.setDestination(destination)
            SMS.setSourceAddr("Mike")
            SMS.setDC("2")
            SMS.setUD("06050423F423F4")
            SMS.setMessage("424547494E3A56434152440D0A56455253494F4E3A322E310D0A4E3A536D6974683B4D696B650D0A54454C3B505245463A2B34343731323334350D0A454E443A56434152440D0A")
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.6 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch ex7_6Ex As HTTPSMS.SMSClientException
            Console.WriteLine(ex7_6Ex.Message)
            Return
        End Try
    End Sub

    'Unicode

    'Unicode message.

    Private Sub example7_7()
        Try
            Dim SMS As New SMS
            SMS.setDestination(destination)
            SMS.setSourceAddr(source)
            SMS.setDC("4")
            SMS.setMessage("00430061007200640042006f00610072006400460069007300680020002d00200054006800650020004e006500780074002000470065006e00650072006100740069006f006e0020006f00660020004d006f00620069006c00650020004d006500730073006100670069006e0067")
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.7 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch ex7_7Ex As HTTPSMS.SMSClientException
            Console.WriteLine(ex7_7Ex.Message)
            Return
        End Try
    End Sub

    'Concatenated SMS

    'Long plain message with User Reference and delivery receipt.
    'This message is 163 characters long so it would require 2 SMS.

    Private Sub example7_8()
        Try
            Dim SMS As New SMS
            SMS.setDestination(destination)
            SMS.setSourceAddr(source)
            SMS.setUserReference("MSG_1")
            SMS.setMessage("Hi! The train is delayed so please pick me up from London road train station. Let me know if you can make it because if not I will catch a taxi. Speak to you soon.")
            Dim responses() As Integer = sendSMS.sendSMS(SMS)
            Console.WriteLine("Example 7.8 Response: ")
            Dim i As Integer = 0
            While i < responses.Length
                Console.WriteLine(responses(i))
                i = i + 1
            End While
        Catch ex7_8Ex As HTTPSMS.SMSClientException
            Console.WriteLine(ex7_8Ex.Message)
            Return
        End Try
    End Sub

End Module