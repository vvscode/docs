'CallbackExample.vb

'Copyright 2007 CardBoardFish
'http://www.cardboardfish.com/
'See readme.txt for terms of use.

'Reference the HTTPSMS DLL:
Imports HTTPSMS

Module CallbackExample

    'Test data - normally the data will come from the server.
    Private incoming As String = "2#1128173:447111111111:447000000000:1:0:1180019698:AF31C0D:#-1:447111111112:447000000003:1::1180019700::48656C6C6F"

    Sub Main()
        'Dimension a new incomingFormat object
        Dim incomingFormat As New HTTPSMS.IncomingFormat
        'Process the data (and catch exceptions)
        Try
            Dim response()() As String = incomingFormat.processIncoming(incoming)
            'Print the data to standard output
            incomingFormat.determineType(response)
        Catch procIncEx As HTTPSMS.SMSClientException
            Console.WriteLine(procIncEx.Message)
            Return
        End Try
    End Sub

End Module
