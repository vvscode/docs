'ClientPolledExample.java

'Copyright 2007 CardBoardFish
'http://www.cardboardfish.com/
'See readme.txt for terms of use.

'This code works on the live system - current delivery receipts are
'required for the code to produce output.

'See SendSMSExample.java for an example of how to send a message
'with a delivery receipt request.

Imports HTTPSMS

Public Class ClientPolledExample

    Private username As String = "username"
    Private password As String = "password"
    Private ClientPolled As New HTTPSMS.ClientPolled

    Public Sub main()
        Try
            ClientPolledExample(username, password)
            example()
        Catch clientEx As HTTPSMS.SMSClientException
            Console.WriteLine(clientEx.Message)
        End Try
    End Sub

    Public Sub ClientPolledExample(ByVal username As String, ByVal password As String)
        ClientPolled.initialise(username, password)
    End Sub

    Public Sub example()
        Try
            Dim response()() As String = ClientPolled.poll()
            Dim incomingFormat As New HTTPSMS.IncomingFormat
            incomingFormat.determineType(response)
        Catch clientExampleEx As HTTPSMS.SMSClientException
            Console.WriteLine(clientExampleEx.Message)
        End Try
    End Sub

End Class
