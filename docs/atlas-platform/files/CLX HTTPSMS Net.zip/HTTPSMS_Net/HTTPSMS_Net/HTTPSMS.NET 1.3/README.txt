CARDBOARDFISH HTTPSMS Microsoft .NET 2.0 API 1.3.0.8 03/08/2010
Copyright 2007-2010 CardBoardFish www.cardboardfish.com

This package contains the following directories:

bin - The HTTPSMS.dll code library
doc - documentation (HTML format, default.html is the start page)
code_examples - Source code demonstrating how the application interacts with the API
SMS_Console - binary and source for a simple console-based SMS program demonstrating the API

For further information and support please visit www.cardboardfish.com.

INSTALLATION

Copy the program SMS_Console and the library HTTPSMS.dll to a location on your 
computer of your choice (they must be in the same directory).  

THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
CARDBOARDFISH BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, IN ANY
CIRCUMSTANCES, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR ITS
USE.
