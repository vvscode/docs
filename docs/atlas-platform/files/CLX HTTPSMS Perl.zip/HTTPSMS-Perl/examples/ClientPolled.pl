#!/usr/bin/perl

# Copyright 2007 CardBoardFish
# http://www.cardboardfish.com/
# See readme.txt for terms of use.

# This code works on the live system - current delivery receipts are
# required for the code to produce output.
#
# See SendSMS.pl for an example of how to send a message with a
# delivery receipt request.

use strict;

use ClientPolled;
use IncomingFormat;

# Your username and password can go here if you want to run the example
# code
my $username = "username";
my $password = "password";

# Required step - the library must have a username and password
# before it attempts to communicate with the server
ClientPolled::initialise($username, $password) or die (ClientPolled->errstr);

my $messages = ClientPolled::poll() or die (ClientPolled->errstr);

IncomingFormat::determineType($messages);
