#!/usr/bin/perl

# Copyright 2007 CardBoardFish
# http://www.cardboardfish.com/
# See readme.txt for terms of use.

use strict;
use IncomingFormat;

# Test data - normally the data will come from the server.
my $INCOMING = '2#1128173:447111111111:447000000000:1:0:1180019698:AF31C0D:#-1:447111111112:447000000003:1:1180019700::48656C6C6F';

# Process the data
my @messages = IncomingFormat::processIncoming($INCOMING);

# Print the data to standard output
IncomingFormat::determineType(@messages);
