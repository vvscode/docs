#!/usr/bin/perl

# Copyright 2007 CardBoardFish
# http://www.cardboardfish.com/
# See readme.txt for terms of use.

# The examples in this file are self-contained in subroutines for
# convenience; uncomment the calls at the end of the file to run them.

# First, inspect the comments below.

use strict;

use SendSMS;
use SMS;

# Your username and password go here
my $username = "username";
my $password = "password";

SendSMS::initialise($username, $password);

# Replace the destination number with your chosen test destination
my $destination = "447000000000";
my $source =      "447111111111";

# Plain Text SMS
# Plain SMS with User Reference and delivery receipt request
sub example7_1 {
    # Construct an SMS object
    my $sms = new SMS();

    # Set the destination address
    $sms->setDA($destination) or die ($sms->errstr);

    # Set the source address
    $sms->setSA($source) or die ($sms->errstr);

    # Set the user reference
    $sms->setUR('AF31C0D') or die ($sms->errstr);

    # Set delivery receipts to 'on'
    $sms->setDR(1) or die ($sms->errstr);

    # Set the message content
    $sms->setMSG('Hello');

    # Send the message and inspect the responses
    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.1 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# Flash SMS
# Plain flash SMS with User Reference and delivery receipt request
sub example7_2 {
    # Construct an SMS object, initialised with certain fields
    my $sms = new SMS($destination, $source, undef, 'Hello', 0, 1, undef, 'MSG_1', undef, undef, undef) or die (SMS->errstr);

    # Send
    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.2 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# Nokia Ringtone
# Ringtone with originator address set to FreeTone
sub example7_3 {
    my $sms = new SMS();

    $sms->setDA($destination);

    # Here we set the source address to something alphanumeric, so
    $sms->setSA('FreeTone');
    # here, we set the source type to alphanumeric
    $sms->setST('5');

    # Set the encoding, user data header and message
    $sms->setDC('2');
    $sms->setUD('06050415810000');
    $sms->setMSG('024A3A7D0995D995C9B195E521A5B1B1CD0DBC0400FD1CD496610624CB084125A242892D049B890A24B31251892CC20C511610824B4485125A0A251214511624CB125A2428A231214516890A24B4125224289290491890A24C31258840841892CC20C499610824B4485125A09371214496624A312598418A22C210496890A24B4144A2428A');

    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.3 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# Nokia Operator Logo
# Operator Logo with numeric originator address, User Reference and
# delivery receipt recorded on account only.
sub example7_4 {
    my $sms = new SMS();

    $sms->setDA($destination);
    $sms->setSA($source);
    $sms->setST('1');
    $sms->setDC('2');
    $sms->setUR('LO_5');
    $sms->setDR('2');
    $sms->setUD('06050415820000');
    $sms->setMSG('32F43300480E010000000000000000000000000000000000000000000000000000000000000000000000003E0005F800004FA06060000D980000D8006060F7BD99CF7BD86F7C6036ADF3636ADFEC6C60F6AD9B6F6AD86F6C60B62D9B6B62D8616C3EF63DF1CF63D86F6C000000000000000000000000000000000000000000000000000000');

    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.4 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# WAP Push
# WAP Push with originator set to Download
sub example7_5 {
    my $sms = new SMS();

    $sms->setDA($destination);
    $sms->setSA('Download');
    $sms->setST('5');
    $sms->setUD('0605040B8423F0');
    $sms->setDC('2');
    $sms->setMSG('01060403AE81EA0205040045C60B037777772E63617264626F617264666973682E636F6D00010343617264426F61726446697368202D20546865204E6578742047656E65726174696F6E206F66204D6F62696C65204D6573736167696E67000101');

    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.5 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# VCard
# VCard with originator set to Mike.
sub example7_6 {
    my $sms = new SMS();

    $sms->setDA($destination);
    $sms->setSA('Mike');
    $sms->setST('5');
    $sms->setUD('06050423F423F4');
    $sms->setDC('2');
    $sms->setMSG('424547494E3A56434152440D0A56455253494F4E3A322E310D0A4E3A536D6974683B4D696B650D0A54454C3B505245463A2B34343731323334350D0A454E443A56434152440D0A');

    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.6 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# Unicode
# Unicode message.
sub example7_7 {
    my $sms = new SMS();

    $sms->setDA($destination);
    $sms->setSA($source);
    $sms->setDC('4');
    $sms->setMSG('00430061007200640042006f00610072006400460069007300680020002d00200054006800650020004e006500780074002000470065006e00650072006100740069006f006e0020006f00660020004d006f00620069006c00650020004d006500730073006100670069006e0067');

    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.7 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# Concatenated SMS
# Long plain message with User Reference and delivery receipt. This
# message is 163 characters long so it would require 2 SMS.
sub example7_8 {
    my $sms = new SMS();

    $sms->setDA($destination);
    $sms->setSA($source);
    $sms->setUR('MSG_1');
    $sms->setDR('1');
    $sms->setMSG('Hi! The train is delayed so please pick me up from London road train station. Let me know if you can make it because if not I will catch a taxi. Speak to you soon.');

    my @responses = SendSMS::sendSMS($sms) or die (SendSMS->errstr);
    print "Example 7.8 Response:\n";
    foreach my $response (@responses) {
        print "\t$response\n";
    }
}

# Uncomment any examples you want to run

# example7_1();
# example7_2();
# example7_3();
# example7_4();
# example7_5();
# example7_6();
# example7_7();
# example7_8();
